
from datetime import datetime

import os

if not os.path.exists("Dados.txt"):
    open("Dados.txt", "w").close()

arquivo = open("Dados.txt", "a")
#Parte1: Primeiro foram criadas todas as funções baseadas nas operações do menu de escolha.
#Parte2: Nessa segunda parte, criamos dentro da função a varialvel "adiciona", que depois colocou todos as informações dentro da lista "Lista_Dados".
#Parte5: Implementamos o envio de dados e atualização de saldo para um arquivo "Dados.txt"
def Novo_cliente():
    data=datetime.now()
    nome = input("Digite o seu nome: ")
    cpf = input("Digite seu CPF: ")
    conta = input("Escolha o seu tipo de conta (comum ou plus): ")
    valorInicial= input("Escolha um valor inicial para abrir a conta: ")
    senha = input("Crie sua senha de 6 dígitos: ")
    adiciona = nome + "," + str(cpf) + "," + conta + "," + str(valorInicial) + "," + str(senha) 
    extratos.append("Data:%.19s + %s Tarifa:0.0 Saldo: %s" % (data,str(valorInicial),str(valorInicial))+"\n")
    Lista_Dados.append(adiciona)
    Lista_Extratos[cpf] = extratos
    print("Nome:", nome, "CPF:", cpf, "Tipo da conta:", conta, "Valor de Abertura:", valorInicial, "Senha:", senha)
    with open("Dados.txt", "a") as arquivo:
        for dadosOrigem in Lista_Dados:
            if cpf in dadosOrigem:
                arquivo.write(adiciona + "\n")
                arquivo.flush()


#Parte2: Em seuida para que a função 2, se conclui-se, criamos um laço de repetição para percorrer toda a lista e apagar as informações do cliente pelo "cpf"
def Apaga_cliente():
    cpf = input("Digite o seu CPF: ")
    print(cpf)
    for x in range(len(Lista_Dados)):
        if cpf in Lista_Dados[x]:
            Lista_Dados.pop(x)
            break
    
    print("Cliente apagado com sucesso!")

#Parte3: Emplementamos na função a "Lista_Dados".
def Listar_clientes():
    print(Lista_Dados)

#Parte3: Foi feito a validação das informações, além da mudança de saldo.
#Parte5: Implementamos as tarifas variavéis mediante a conta do cliente, além do valor máximo para saldo negativo.
def Debito():
    data=datetime.now()
    cpf = input("Digite o seu CPF: ")
    senha = input("Insira sua senha: ")
    valor = input("Digite o valor desejado: ")
    for x in range(len(Lista_Dados)):
        if cpf in Lista_Dados[x]:
            if senha in Lista_Dados[x]:
                dadosOrigem = Lista_Dados[x].split(",")
                cpf = dadosOrigem[1]
                nome = dadosOrigem[0]
                conta = dadosOrigem[2]
                saldo = dadosOrigem[3]
                senha = dadosOrigem[4]
                tarifa = {
                    "comum": 1.05,
                    "plus": 1.03
                }
                if conta == "comum" and (float(saldo) - float(valor)) < -1000:
                    print("O seu saldo é insuficiente para efetuar a operação.")
                    return
                elif conta == "plus" and (float(saldo) - float(valor)) < -5000:
                    print("O seu saldo é insuficiente para efetuar a operação.")
                    return
                taxa = tarifa.get(conta)
                saldo = float(saldo) - float(valor) * float(taxa)
                adiciona = nome + "," + str(cpf) + "," + conta + "," + str(saldo) + "," + str(senha)
                extratos.append("Data:%.19s - %s Tarifa:%s Saldo: %s" % (data,valor,taxa,saldo) + "\n")
                Lista_Extratos[cpf] = extratos 
                print("Operação Efetuada")
    with open("Dados.txt", "a") as arquivo:
        for dadosOrigem in Lista_Dados:
            arquivo.write(adiciona + "\n")
            arquivo.flush()
                
    print("CPF:", cpf, "Valor Debitado:", valor)

#Parte3: Foi feito a validação das informações, além da mudança de saldo.
def Deposito():
    data=datetime.now()
    cpf = input("Digite o seu CPF: ")
    valor = input("Digite o valor desejado: ")
    for x in range(len(Lista_Dados)):
        if cpf in Lista_Dados[x]:
            dadosOrigem = Lista_Dados[x].split(",")
            cpf = dadosOrigem[1]
            nome = dadosOrigem[0]
            conta = dadosOrigem[2]
            saldo = dadosOrigem[3]
            senha = dadosOrigem[4]
            saldo = float(saldo) + float(valor)
            adiciona = nome + "," + str(cpf) + "," + conta + "," + str(saldo) + "," + str(senha)
            extratos.append("Data:%.19s + %s Tarifa:0.0 Saldo: %s" % (data,valor,saldo)+"\n")
            Lista_Extratos[cpf] = extratos  
            print("Operação Efetuada")
    with open("Dados.txt", "a") as arquivo:
        for dadosOrigem in Lista_Dados:
            arquivo.write(adiciona + "\n")
            arquivo.flush()

    print("CPF:", cpf, "Valor Depositado:", valor)

#Parte4: Implementamos a funcionalidade a função "Extrato", podem ver as movimentações bancárias.
def Extrato():
    cpf = input("Digite o seu CPF: ")
    senha = input("Insira sua senha: ")
    for x in range(len(Lista_Dados)):
        if cpf in Lista_Dados[x]:
            if senha in Lista_Dados[x]:
                dadosOrigem = Lista_Dados[x].split(",")
                cpf = dadosOrigem[1]
                nome = dadosOrigem[0]
                conta = dadosOrigem[2]

    print("Nome:", nome)
    print("CPF:", cpf)
    print("Tipo de Conta:", conta)
    print(Lista_Extratos)

#Parte3: Foi feito a validação das informações, além da mudança de saldo.
def Transferencia():
    data=datetime.now()
    cpf = input("Digite o seu CPF: ")
    for x in range(len(Lista_Dados)):
        if cpf in Lista_Dados[x]:
            senha = input("Insira sua senha: ")
            if senha in Lista_Dados[x]:
                dadosOrigem = Lista_Dados[x].split(",")
                cpf = dadosOrigem[1]
                nome = dadosOrigem[0]
                conta = dadosOrigem[2]
                saldo = dadosOrigem[3]
                senha = dadosOrigem[4]
                cpfDest = input("Digite o CPF do destinatário: ")
                valor = input("Digite o valor desejado: ")
                for y in range(len(Lista_Dados)):
                    if cpf in Lista_Dados[y]:
                        saldo = float(saldo) - float(valor)
                        clienteOrigem = nome + "," + str(cpf) + "," + conta + "," + str(saldo) + "," + str(senha)
                        Lista_Dados.pop(x)
                        Lista_Dados.append(clienteOrigem)
                        dadosDestino = Lista_Dados[y].split(",")
                        cpfDest = dadosDestino[1]
                        nomeDest = dadosDestino[0]
                        contaDest = dadosDestino[2]
                        saldoDest = float(dadosDestino[3]) + float(valor)
                        senhaDest = dadosDestino[4]
                        clienteDestino = nomeDest + "," + str(cpfDest) + "," + contaDest + "," + str(saldoDest) + "," + str(senhaDest)
                        Lista_Dados.pop(y)
                        Lista_Dados.append(clienteDestino)
                        extratos.append("Data:%.19s - %s Tarifa:0.0 Saldo: %s" % (data,valor,saldo)+"\n")
                        Lista_Extratos[cpf] = extratos
                        extratos.append("Data:%.19s + %s Tarifa:0.0 Saldo: %s" % (data,valor,saldo)+"\n")
                        Lista_Extratos[cpfDest] = extratos 
                        break
                    print("Operação Efetuada")
    with open("Dados.txt", "a") as arquivo:
        for dadosOrigem in Lista_Dados:
            if cpf in dadosOrigem:
                arquivo.write(clienteOrigem + "\n")
                arquivo.flush()
        for dadosDestino in Lista_Dados:
            if cpfDest in dadosDestino:
                arquivo.write(clienteDestino + "\n")
                arquivo.flush()
    
    print("CPF:", cpf, "CPF Destinatário:", cpfDest, "Valor da Transferência:", valor)

#Parte1: Pensamos na recarga de celular como a nossa Opção Livre
#Parte4: Implementamos a funcionalidade da nossa "Função Livre", que no caso é a Reacarga de Celular. 
def Recarga_Celular():
    data=datetime.now()
    numCel = int(input("Insira seu número de celular: "))
    operadora = input("Qual a operadora do número: ")
    valor = float(input("Escolha o valor da recarga: "))
    cpf = input("Digite o seu CPF: ")
    for x in range(len(Lista_Dados)):
        if cpf in Lista_Dados[x]:
            dadosOrigem = Lista_Dados[x].split(",")
            cpf = dadosOrigem[1]
            nome = dadosOrigem[0]
            conta = dadosOrigem[2]
            saldo = dadosOrigem[3]
            senha = dadosOrigem[4]
            saldo = float(saldo) - float(valor)
            adiciona = nome + "," + str(cpf) + "," + conta + "," + str(saldo) + "," + str(senha)
            extratos.append("Data:%.19s - %s Tarifa:0.0 Saldo: %s" % (data,valor,saldo)+"\n")
            Lista_Extratos[cpf] = extratos 
            print("Operação Efetuada")
    with open("Dados.txt", "a") as arquivo:
        for dadosOrigem in Lista_Dados:
            arquivo.write(adiciona + "\n")
            arquivo.flush()

    print("Número do Celular:", numCel, "Operadora:", operadora, "Valor da Recarga:", valor)

def Sair():
    print("Você saiu! Até a próxima")
    
#Parte2: Em seguida criamos o laço de repetição para efetuar as operações até dar o comando de saida, e criando a variável "escolha", para o usuário escolher a operação.  

extratos=[]
Lista_Extratos = {}
Lista_Dados = []

while True:
    print("1. Novo Cliente")
    print("2. Apaga Cliente")
    print("3. Listar Clientes")
    print("4. Débito")
    print("5. Depósito")
    print("6. Extrato")
    print("7. Transferência ente Contas")
    print("8. Recarga de Celular")
    print("9. Sair")
    escolha = input("Escolha a operação desejada: ")
    if escolha == "1":
        Novo_cliente()
    elif escolha == "2":
        Apaga_cliente()
    elif escolha == "3":
        Listar_clientes()
    elif escolha == "4":
        Debito()
    elif escolha == "5":
        Deposito()
    elif escolha == "6":
        Extrato()
    elif escolha == "7":
        Transferencia()
    elif escolha == "8":
        Recarga_Celular()
    elif escolha == "9":
        Sair()
        break

arquivo.close()